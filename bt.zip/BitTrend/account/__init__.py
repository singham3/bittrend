default_app_config = 'BitTrend.account.apps.ExampleAppConfig'
