from django.apps import AppConfig


class CryptowalletConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'BitTrend.cryptowallet'
