from .models import *
from rest_framework import serializers


class CryptoWalletSerializer(serializers.ModelSerializer):
    class Meta:
        model = CryptoWallet
        fields = "__all__"


class CryptoOrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = Order
        fields = "__all__"


class WithdrawHistorySerializer(serializers.ModelSerializer):
    class Meta:
        model = WithdrawHistory
        fields = "__all__"


class GetCryptoWalletSerializer(serializers.ModelSerializer):

    class Meta:
        model = CryptoWallet
        fields = ('coin', 'network_address')
